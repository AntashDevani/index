from passlib.hash import pbkdf2_sha256

class base(object):
	BASE="ADs"
	lang="python3"

	def __init__(self):
		return 

	def fg(self,text,color):
		return "\33[38;5;" + str(color) + "m" + text + "\33[0m"

	def decrypt(self,code):
		return pbkdf2_sha256.verify(self,code.replace("@",'$').replace("_","-"))

if __name__=="__main__":
	base()